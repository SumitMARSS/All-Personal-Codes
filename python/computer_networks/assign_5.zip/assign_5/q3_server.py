import socket
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import requests

def web_crawler(url, depth):
    visited = set()
    to_visit = [url]

    while to_visit and depth > 0:
        current_url = to_visit.pop(0)
        if current_url not in visited:
            try:
                response = requests.get(current_url)
                visited.add(current_url)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.content, 'html.parser')
                    print("Links from", current_url)
                    for link in soup.find_all('a'):
                        next_url = link.get('href')
                        if next_url:
                            if next_url.startswith('http'):
                                print(next_url)
                                to_visit.append(next_url)
                            else:
                                next_url = urlparse(current_url).scheme + "://" + urlparse(current_url).netloc + "/" + next_url
                                print(next_url)
                                to_visit.append(next_url)
            except Exception as e:
                print("Error:", e)
        depth -= 1

def main():
    host = '127.0.0.1'
    port = 12345

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)

    print("Server listening on port", port)

    while True:
        client_socket, addr = server_socket.accept()
        print("Connection from", addr)

        while True:
            data = client_socket.recv(1024).decode('utf-8')
            if not data:
                break
            if data.lower() == 'quit':
                break
            url, depth = data.split(',')
            print("Received URL:", url)
            print("Depth:", depth)
            web_crawler(url, int(depth))

        client_socket.close()

if __name__ == "__main__":
    main()
